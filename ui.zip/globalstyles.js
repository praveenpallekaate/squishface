import {StyleSheet} from 'react-native';
import {commonPalette, darkPalette} from './color';

export const currentTheme = darkPalette;
export const commonColorPalette = commonPalette;

export const globalStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: currentTheme.primaryBGColor,
    padding: 24,
    paddingTop: 35
  },
  flex: {
    flex: 1
  },
  flexRow: {
    flexDirection: 'row'
  },
  flexReverse: {
    flexDirection: 'row-reverse'
  },
  flexGrow: {
    flexGrow: 1,
  },
  alignCenter: {
    alignItems: 'center'
  },
  text: {
    color: currentTheme.primaryTextColor
  },
  textSecondary: {
    color: currentTheme.secondaryTextColor
  },
  text1: {
    color: commonPalette.cyan
  },
  text2: {
    color: commonPalette.neonGreen
  },
  text3: {
    color: commonPalette.orange
  },
  text4: {
    color: commonPalette.pink
  },
  text5: {
    color: commonPalette.purple
  },
  text6: {
    color: commonPalette.red
  },
  text7: {
    color: commonPalette.yellow
  },
  fontConsolas: {
    fontFamily: 'consolas'    
  },
  fontCourier: {
    fontFamily: 'courier-new'    
  },
  fontMonospace: {
    fontFamily: 'monospace'    
  },
  input: {
    borderWidth: 1,
    borderStyle: 'solid',
    borderColor: currentTheme.secondaryTextColor,
    color: currentTheme.primaryTextColor,
    fontSize: 18,
    padding: 5
  }
});