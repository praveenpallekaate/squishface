import helper from './app/utils/helper';

const getRandomColor = () => {
  switch (helper.getRandomNumber(1, 7)) {
    case 1:
      return commonPalette.cyan;
    case 2:
      return commonPalette.purple;
    case 3:
      return commonPalette.neonGreen;
    case 4:
      return commonPalette.yellow;
    case 5:
      return commonPalette.red;
    case 6:
      return commonPalette.orange;
    case 7:
      return commonPalette.pink;
    default:
      break;
  }
};

export const commonPalette = {
  cyan: '#1cd0c6',
  purple: '#b84aed',
  neonGreen: '#67d572',
  yellow: '#ffda4f',
  red: '#db3d37',
  orange: '#e66b30',
  pink: '#dc00aa',
  randomColor: getRandomColor
};

export const darkPalette = {
  primaryBGColor: '#262a33',
  primaryTextColor: '#d5ced9',
  secondaryTextColor: '#5f6167',
  heartColor: '#ff8080'
};

export const lightPalette = {
  primaryBGColor: '#fefefe',
  primaryTextColor: '#262a33',
  secondaryTextColor: '#2e323d',
  heartColor: '#ff8080'
};