import React, {useState} from 'react';
import {
  StyleSheet, View, Text, TextInput, 
  Button, TouchableOpacity} from 'react-native';
import {commonColorPalette, currentTheme, globalStyles } from '../../../globalstyles';
import { LOGINSCREEN_CONST, COMMON_CONST } from '../../constants';
import UserAPI from '../../api/user';
import helper from '../../utils/helper';

const color = commonColorPalette.randomColor();

export default function NewUser({handleSignIn, toggleView}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [invalid, setInvalid] = useState(false);
  const [duplicate, setDuplicate] = useState(false);

  const signUpUser = () => {
    const userName = name.trim();
    const pwd = password.trim();
    const mail = email.trim();

    if(
      userName && 
      pwd &&
      confirmPassword.trim() &&
      mail){      
      if(password !== confirmPassword){
        setInvalid(true);
      } else {
        UserAPI
          .addUser({
            name: userName,
            password: pwd,
            email: mail
          }).then(response => {
            if(helper.isSuccess(response)){
              if(response.data.length > 0){
                handleSignIn(name);
              } else {
                setInvalid(true);
              }
            }
          }).catch(error => {
            if(error.response.status === 409){
              setDuplicate(true);
            }
          });
      }      
    }    
  }

  return (
    <View style={globalStyles.flex}>
      <View style={newUserStyle.section}>
        <TextInput
          placeholder="User name"
          placeholderTextColor={currentTheme.secondaryTextColor}
          style={[globalStyles.input, newUserStyle.input]} 
          value={name}
          onChangeText={(val) => setName(val)}
        />
        <TextInput
          secureTextEntry={true}
          placeholder="Password"
          placeholderTextColor={currentTheme.secondaryTextColor}
          style={
            invalid
            ? [globalStyles.input, newUserStyle.input, newUserStyle.invalid]
            : [globalStyles.input, newUserStyle.input]
          } 
          value={password}
          onChangeText={(val) => setPassword(val)}
        />
        <TextInput
          secureTextEntry={true}
          placeholder="Confirm Password"
          placeholderTextColor={currentTheme.secondaryTextColor}
          style={
            invalid
            ? [globalStyles.input, newUserStyle.input, newUserStyle.invalid]
            : [globalStyles.input, newUserStyle.input]
          } 
          value={confirmPassword}
          onChangeText={(val) => setConfirmPassword(val)}
        />
        <TextInput
          placeholder="Email"
          placeholderTextColor={currentTheme.secondaryTextColor}
          style={
            duplicate
            ? [globalStyles.input, newUserStyle.input, newUserStyle.invalid]
            : [globalStyles.input, newUserStyle.input]
          } 
          value={email}
          onChangeText={(val) => setEmail(val)}
        />
        <View style={newUserStyle.otherSection}>
          <Button
            title="Sign Up"
            color={color}
            onPress={signUpUser}
          />
        </View>
        <View style={[newUserStyle.otherSection, newUserStyle.loginOptions, globalStyles.alignCenter]}>
          <TouchableOpacity onPress={() => toggleView(LOGINSCREEN_CONST.newUser)}>
            <Text style={globalStyles.text}>Go back</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const newUserStyle = StyleSheet.create({
  section: {
    paddingTop: 40
  },
  otherSection: {
    paddingTop: 20
  },
  input: {
    marginTop: 20,
    minWidth: 200
  },
  loginOptions: {
    paddingLeft: 10
  },
  invalid: {
    borderColor: commonColorPalette.red
  }
});