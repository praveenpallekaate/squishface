import React from 'react';
import {StyleSheet, View, Text, TouchableOpacity} from 'react-native';
import { commonColorPalette, globalStyles } from '../../../globalstyles';
import { LOGINSCREEN_CONST } from '../../constants';

export default function ForgotPassword({toggleView}) {
  return (
    <View style={globalStyles.flex}>
      <View style={[forgotStyles.otherSection, forgotStyles.loginOptions, globalStyles.alignCenter]}>
        <TouchableOpacity onPress={() => toggleView(LOGINSCREEN_CONST.forgotPassword)}>
          <Text style={globalStyles.text}>Go back</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const forgotStyles = StyleSheet.create({
  section: {
    paddingTop: 40
  },
  otherSection: {
    paddingTop: 20
  },
  input: {
    marginTop: 20,
    minWidth: 200
  },
  loginOptions: {
    paddingLeft: 10
  },
  invalid: {
    borderColor: commonColorPalette.red
  }
});