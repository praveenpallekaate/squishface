import React, {useState} from 'react';
import {
  StyleSheet, View, Text, TextInput, 
  Button, TouchableOpacity} from 'react-native';
import {commonColorPalette, currentTheme, globalStyles } from '../../../globalstyles';
import { LOGINSCREEN_CONST, COMMON_CONST } from '../../constants';
import UserAPI from '../../api/user';
import helper from '../../utils/helper';

const color = commonColorPalette.randomColor();

export default function Login({handleSignIn, toggleView}) {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [invalid, setInvalid] = useState(false);

  const loginUser = () => {
    const userName = name.trim();

    if(userName && password.trim()){
      UserAPI
        .loginUser({
          name: name,
          password: password
        }).then(response => {
          if(helper.isSuccess(response)){
            if(response.data === COMMON_CONST.valid){
              handleSignIn(name);
            } else {
              setInvalid(true);
            }
          }
        });
    }    
  }

  return (
    <View style={[globalStyles.flex, globalStyles.alignCenter]}>
      <View style={loginStyle.section}>
        <Text style={loginStyle.appName}>SQUISH FACE</Text>
      </View>
      <View style={loginStyle.section}>
        <TextInput
          placeholder="User name"
          placeholderTextColor={currentTheme.secondaryTextColor}
          style={[globalStyles.input, loginStyle.input]} 
          value={name}
          onChangeText={(val) => setName(val)}
        />
        <TextInput
          secureTextEntry={true}
          placeholder="Password"
          placeholderTextColor={currentTheme.secondaryTextColor}
          style={
            invalid
            ? [globalStyles.input, loginStyle.input, loginStyle.invalid]
            : [globalStyles.input, loginStyle.input]
          } 
          value={password}
          onChangeText={(val) => setPassword(val)}
        />
        <View style={loginStyle.otherSection}>
          <Button
            title="Login"
            color={color}
            onPress={loginUser}
          />
        </View>        
        <View style={[globalStyles.flexRow, loginStyle.otherSection, loginStyle.loginOptions]}>
          <TouchableOpacity onPress={() => toggleView(LOGINSCREEN_CONST.newUser)}>
            <Text style={globalStyles.text}>{LOGINSCREEN_CONST.newUser}</Text>
          </TouchableOpacity>
          <Text style={globalStyles.text}> | </Text>
          <TouchableOpacity onPress={() => toggleView(LOGINSCREEN_CONST.forgotPassword)}>
            <Text style={globalStyles.text}>{LOGINSCREEN_CONST.forgotPassword}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const loginStyle = StyleSheet.create({
  appName: {
    fontSize:30,
    fontWeight: 'bold',
    color: color
  },
  section: {
    paddingTop: 40
  },
  otherSection: {
    paddingTop: 20
  },
  input: {
    marginTop: 20,
    minWidth: 200
  },
  loginOptions: {
    paddingLeft: 10
  },
  invalid: {
    borderColor: commonColorPalette.red
  }
});