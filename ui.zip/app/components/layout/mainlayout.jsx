import React, {Component} from 'react';
import {StyleSheet, View, Text, TextInput, TouchableOpacity} from 'react-native';
import {globalStyles} from '../../../globalstyles';
import Chat from '../chat/chat';
import Login from '../login/login';
import { LOGINSCREEN_CONST } from '../../constants';
import ForgotPassword from '../login/forgotpassword';
import NewUser from '../login/newuser';

export default class MainLayout extends Component {
  constructor(props){
    super(props);

    this.state = {
      user: '',
      showNewUser: false,
      showForgotUser: false
    };
  }

  componentDidMount = () => {

  }

  handleUserLogin = (val) => {
    if(val){
      this.setState({user: val});
    }
  }

  toggleView = (type) => {
    let {showForgotUser, showNewUser} = this.state;

    switch (type) {
      case LOGINSCREEN_CONST.newUser:
        showNewUser = !showNewUser;
        break;
      case LOGINSCREEN_CONST.forgotPassword:
        showForgotUser = !showForgotUser;
        break;
      default:
        break;
    }

    this.setState({
      showForgotUser: showForgotUser,
      showNewUser: showNewUser
    });
  }

  render(){
    const {
      user,
      showForgotUser,
      showNewUser
    } = this.state;

    return (
      <View style={globalStyles.flex}>
      {
        user
        ? (
            <Chat user={user} />
          )
        : (
            <View style={globalStyles.flex}>
            {
              showNewUser
              ? (
                  <View style={globalStyles.flex}>
                    <NewUser
                      handleSignIn={this.handleUserLogin}
                      toggleView={this.toggleView}
                    />
                  </View>
                )
              : (
                  <View style={globalStyles.flex}>
                  {
                    showForgotUser
                    ? (
                        <View style={globalStyles.flex}>
                          <ForgotPassword
                            toggleView={this.toggleView}
                          />
                        </View>
                      )
                    : (
                        <View style={globalStyles.flex}>
                          <Login
                            handleSignIn={this.handleUserLogin}
                            toggleView={this.toggleView}
                          />
                        </View>
                      )
                  }
                  </View>
                )
            }
            </View>
          )    
      }
      </View>
    );
  }
}