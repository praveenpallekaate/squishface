import React from 'react';
import {View, Text, ScrollView, TouchableOpacity} from 'react-native';
import { commonColorPalette, globalStyles } from '../../../globalstyles';
import ChatBubble from './chatbubble';

export default function ChatContainer({
  user, 
  loadMore,
  messageDetails, 
  handleLikeMessage, 
  handleLoadMore
}) {
  const highlightColor = commonColorPalette.randomColor();

  return (
    <View style={globalStyles.flex}>
    {
      messageDetails.length > 0
      ? (
          <ScrollView>
            {
              messageDetails.map((messageDetail, index) => (
                <ChatBubble 
                  user={user}
                  highlightColor={highlightColor}
                  messageDetail={messageDetail} 
                  key={index}
                  handleLikeMessage={handleLikeMessage}
                />
              ))
            }
            {
              !loadMore
              ? <View style={globalStyles.alignCenter}>
                  <TouchableOpacity onPress={handleLoadMore}>
                    <Text style={globalStyles.text}>Load more..</Text>
                  </TouchableOpacity>
                </View>
              : <View></View>
            }
          </ScrollView>
        )
      : (
          <Text style={globalStyles.text}>No messages yet!</Text>
        )
    }      
    </View>
  );
}