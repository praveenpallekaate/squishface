import React from 'react';
import {StyleSheet, View, TextInput, TouchableOpacity} from 'react-native';
import {currentTheme , globalStyles } from '../../../globalstyles';
import { FontAwesome } from '@expo/vector-icons';

export default function ChatInput({submitChat, handleTextChange, chatText}) {
  return (
    <View style={[globalStyles.flexRow, globalStyles.alignCenter, inputStyle.container]}>
      <View style={[globalStyles.flexGrow, inputStyle.inputView]}>
        <TextInput 
          multiline 
          placeholder="Type here.."
          placeholderTextColor={currentTheme.secondaryTextColor}
          style={[globalStyles.input, inputStyle.input]} 
          value={chatText}
          onChangeText={(val) => handleTextChange(val)}          
        />
      </View>
      <View style={inputStyle.sendView}>
        <TouchableOpacity onPress={submitChat}>
          <FontAwesome 
            name="send"  
            size={18}
            color={currentTheme.secondaryTextColor} 
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const inputStyle = StyleSheet.create({
  container:{
    
  },
  sendView: {
    padding: 5,
    paddingLeft: 10,
  },
  input: {
    width: '95%'
  },
  inputView: {
    width: '95%'
  }
});