import React from 'react';
import {StyleSheet, View, Text, TouchableOpacity} from 'react-native';
import { currentTheme, globalStyles } from '../../../globalstyles';
import ChatTextBuilder from '../shared/chattextbuilder';
import helper from '../../utils/helper';
import { FontAwesome } from '@expo/vector-icons';

export default function ChatBubble({user, highlightColor, messageDetail, handleLikeMessage}) {
  const likes = messageDetail.likes && messageDetail.likes.length > 0
    ? messageDetail.likes.length : 0;
  const bubbleHighlight = messageDetail.by === user
    ? [bubbleStyles.bubble, {borderColor: highlightColor}]
    : bubbleStyles.bubble;  

  return (
    <View style={[globalStyles.flexRow, globalStyles.alignCenter]}>
      <View style={globalStyles.flexGrow}>
        <TouchableOpacity 
          onPress={() => handleLikeMessage(
            {
              id: messageDetail.id, 
              by: messageDetail.by
            }
          )}
        >
          <View style={bubbleHighlight}>
            <View>
              <ChatTextBuilder text={messageDetail.text} />
            </View>      
            <View style={globalStyles.flexReverse}>
              <Text style={globalStyles.textSecondary}>{messageDetail.by}</Text>
            </View>
            <View style={globalStyles.flexReverse}>
              <Text style={globalStyles.textSecondary}>
              {helper.formatDate(messageDetail.on)}
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
      <View style={bubbleStyles.heartView}>
      {
        likes > 0
        ? (
            <View>
              <FontAwesome
                name="heart"
                size={18}
                color={currentTheme.heartColor}          
              />
              <View style={bubbleStyles.likeText}>
                <Text style={globalStyles.textSecondary}>
                {
                  messageDetail.likes.length < 9
                  ? ' ' + messageDetail.likes.length
                  : helper.formatThousands(messageDetail.likes.length)
                }
                </Text>
              </View>              
            </View>
          )
        : <View></View>
      }        
      </View>
    </View>
  );
}

const bubbleStyles = StyleSheet.create({
  bubble: {
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: currentTheme.secondaryTextColor,
    borderRadius: 2,
    padding: 25,
    marginBottom: 25    
  },
  heartView: {
    paddingLeft: 15
  },
  likeText: {
    paddingTop: 5
  }
})