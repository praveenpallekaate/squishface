import React, {Component} from 'react';
import {View, KeyboardAvoidingView} from 'react-native';
import { globalStyles } from '../../../globalstyles';
import ChatContainer from './chatcontainer';
import ChatInput from './chatinput';
import MessageAPI from '../../api/message';
import { AppLoading } from 'expo';
import {COMMON_CONST} from '../../constants/index';
import helper from '../../utils/helper';
import message from '../../api/message';

export default class Chat extends Component{
  constructor(props){
    super(props);

    this.state = {
      user: props.user || '',
      chatText: '',
      messageDetails: [],
      loadedAllMessages: false
    };
  }

  componentDidMount = () => {    
    const looper = setInterval(() => {
      const {loadedAllMessages} = this.state;
      if(loadedAllMessages){
        this.getMessages(true);
      } else {
        this.getMessages();
      }
    }, 6000)        
  }

  handleAddChat = () => {
    let {
      user, 
      chatText, 
      messageDetails} = this.state;
  
    const val = chatText.trim();

    if(!val){
      return false;
    }

    messageDetails = [...messageDetails].reverse();

    messageDetails.push({
      text: chatText.trim(),
      by: user,
      on: new Date()
    });

    messageDetails = [...messageDetails].reverse();
    chatText = '';

    this.setState({
      chatText: chatText, 
      messageDetails: messageDetails
    }, () => {
      MessageAPI
        .addMessage({
          text: val,
          by: user
        }).then((response) => {

        });
    });
  }

  handleTextChange = (val) => {
    let {chatText} = this.state;

    chatText = val;

    this.setState({chatText: chatText});
  }

  handleLikeMessage = (val) => {
    if(val){
      let {user, messageDetails} = this.state;

      if(user !== val.by){
        messageDetails = messageDetails.map(messageDetail => {
          if(messageDetail.id === val.id){
            if(messageDetail.likes && messageDetail.likes.length > 0){
              var hasUserInLike = messageDetail.likes.filter(i => i.by === user);

              if(hasUserInLike.length > 0){
                messageDetail.likes = messageDetail.likes.filter(j => j.by !== user);
              } else {
                messageDetail.likes.push({
                  by: user,
                  on: new Date()
                });  
              }
            } else {
              messageDetail.likes = [];
              messageDetail.likes.push({
                by: user,
                on: new Date()
              });
            }
          }

          return messageDetail;
        });

        this.setState({messageDetails: messageDetails}, () => {
          MessageAPI
            .toggleLikeMessage({
              id: val.id,
              likedBy: user
            });
        });        
      }
    }
  }

  handleLoadMore = () => {
    this.getMessages(true);
  }

  getMessages = (all) => {    
    let {messageDetails, loadedAllMessages} = this.state;

    if(all){
      MessageAPI
        .getMessages()
        .then((response) => {
          if(helper.isSuccess(response)){
            messageDetails = response.data;
            loadedAllMessages = true;

            this.setState({
              messageDetails: messageDetails,
              loadedAllMessages: loadedAllMessages
            });
          }
        });
    } else {
      MessageAPI
        .getMessages(COMMON_CONST.startMessageCount)
        .then((response) => {
          if(helper.isSuccess(response)){
            messageDetails = response.data;

            this.setState({messageDetails: messageDetails});
          }
        });
    }
  }

  render(){
    return (
      <KeyboardAvoidingView 
        style={globalStyles.flex} 
        behavior="padding"
      >
        <View style={globalStyles.flexGrow}>
          <ChatContainer 
            user={this.state.user}
            loadMore={this.state.loadedAllMessages}
            messageDetails={this.state.messageDetails}
            handleLikeMessage={this.handleLikeMessage}
            handleLoadMore={this.handleLoadMore}
          />
        </View>
        <View>
          <ChatInput 
            chatText={this.state.chatText}
            handleTextChange={this.handleTextChange}
            submitChat={this.handleAddChat} 
          />
        </View>
      </KeyboardAvoidingView>
    );
  }
}