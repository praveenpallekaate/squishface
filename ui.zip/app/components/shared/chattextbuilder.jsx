import React from 'react';
import {Text, StyleSheet} from 'react-native';
import helper from '../../utils/helper';
import { globalStyles } from '../../../globalstyles';

export default function ChatTextBuilder({text}) {
  const wordAry = helper.splitWordsToArray(text);  

  return (
    <Text 
      style={
        [
          chatStyle.font, 
          globalStyles.fontConsolas, 
          globalStyles.fontCourier, 
          globalStyles.fontMonospace
        ]
      }
    >
    {
      wordAry.map((word, index) => {
        let style = globalStyles.text;

        if(word.length > 3){
          switch (helper.getRandomNumber(1, 7)) {
            case 1:
              style = globalStyles.text1;
              break;
            case 2:
              style = globalStyles.text2;
              break;
            case 3:
              style = globalStyles.text3;
              break;
            case 4:
              style = globalStyles.text4;
              break;
            case 5:
              style = globalStyles.text5;
              break;
            case 6:
              style = globalStyles.text6;
              break;
            case 7:
              style = globalStyles.text7;
              break;
            default:
              break;
          }
        }        

        return (
          <Text style={style} key={index}>
          {index === 0 ? word : ' ' + word}
          </Text>
        );
      })
    }
    </Text>
  )
}

const chatStyle = StyleSheet.create({
  font: {
    fontSize: 18
  }
});