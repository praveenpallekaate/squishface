const STATICURLS_CONST = {
  local: 'https://localhost:44324/api/',
  environment: '' + '/api/'
};

const COMMONURLS_CONST = {
  apibaseurl: STATICURLS_CONST.environment,
};

const COMMON_CONST = {
  startMessageCount: 10,
  valid: 'valid'
};

const LOGINSCREEN_CONST = {
  newUser: 'New User',
  forgotPassword: 'Forgot Password'
}

export {
  STATICURLS_CONST,
  COMMON_CONST,
  COMMONURLS_CONST,
  LOGINSCREEN_CONST
};