import {COMMONURLS_CONST} from '../constants/index';
import {axiosInstance} from './axioshelp';

const jsonHeader = {'Content-Type': 'application/json'};

const getMessages = (count) => {
  let apiUrl = '';

  if(count){
    apiUrl = COMMONURLS_CONST.apibaseurl + 'message/by?count=' + count;
  } else {
    apiUrl = COMMONURLS_CONST.apibaseurl + 'message';
  }

  return axiosInstance.get(apiUrl)
    .then((response) => {
      return response;
    })
    .catch((error) => {
      console.log(error);
      throw error;
    });
};

const addMessage = (message) => {
  const apiUrl = COMMONURLS_CONST.apibaseurl + 'message';

  return axiosInstance.post(apiUrl, message, jsonHeader)
    .then((response) => {
        return response;
    })
    .catch((error) => {
      console.log(error);
      throw error;
    });
};

const toggleLikeMessage = (message) => {
  const apiUrl = COMMONURLS_CONST.apibaseurl + 'message';

  return axiosInstance.put(apiUrl, message, jsonHeader)
    .then((response) => {
        return response;
    })
    .catch((error) => {
      console.log(error);
      throw error;
    });
};

export default {
  getMessages,
  addMessage,
  toggleLikeMessage
};