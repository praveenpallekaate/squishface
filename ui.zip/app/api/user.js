import {COMMONURLS_CONST} from '../constants/index';
import {axiosInstance} from './axioshelp';

const jsonHeader = {'Content-Type': 'application/json'};

const loginUser = (creds) => {
  const apiUrl = COMMONURLS_CONST.apibaseurl + 'user/login';

  return axiosInstance.post(apiUrl, creds, jsonHeader)
    .then((response) => {
        return response;
    })
    .catch((error) => {
      console.log(error);
      throw error;
    });
};

const addUser = (user) => {
  const apiUrl = COMMONURLS_CONST.apibaseurl + 'user';

  return axiosInstance.post(apiUrl, user, jsonHeader)
    .then((response) => {
        return response;
    })
    .catch((error) => {
      console.log(error);
      throw error;
    });
};

export default {
  loginUser,
  addUser
}