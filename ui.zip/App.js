import React, {useState} from 'react';
import { Text, View } from 'react-native';
import {globalStyles} from './globalstyles';
import ChatTextBuilder from './app/components/shared/chattextbuilder';
import { AppLoading } from 'expo';
import * as Font from 'expo-font';
import MainLayout from './app/components/layout/mainlayout';

export const getFonts = () => Font.loadAsync({
  'consolas': require('./assets/fonts/Consolas.ttf'),
  'courier-new': require('./assets/fonts/cour.ttf'),
  'monospace': require('./assets/fonts/monospace.ttf')
});

export default function App() {
  const [fontLoaded, setFontLoaded] = useState(false);

  if(fontLoaded){
    return (
      <View style={globalStyles.container}>
        <MainLayout />
      </View>
    )
  } else {
    return (
      <AppLoading
        startAsync={getFonts}
        onFinish={() => setFontLoaded(true)}
      />
    )
  }  
}
